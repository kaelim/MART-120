var x = 270;
var y = 250;
var diameter = 200;
var movement;
var a = 300;
var b = 275;
var size = 22;
var count = 0;
var sizeDirection = 2;
function setup()
 {
    createCanvas(500, 600);
    movement = floor(random()* 10);
 }

 

function draw()
{
    background(120, 45, 78);
   
    fill(250, 10, 250);
    rect(125, 350, 250, 400);
    rect(100, 350, 50, 300);
    
    rect(x, y, x, y);
    x++;
    if(x >= 800 || x<=0 ) {
        movement *= -1;
    
    }
 x += movement; 
    

    fill(178, 34, 389);
    rect(125, 100, 240, 240);

    fill(255, 204, 0);
    circle(x, y, diameter);
    x++;
    if(x >= 800 || x<=0 ) {
        movement *= -1;
    
    }
 x += movement; 
    fill(100, 60, 275);
    triangle(200,400, 200, 450, 300, 400);
    triangle(260, 400, 300, 450, 350, y);
    y++;
    if(y >= 600 || y<=0 ) {
        movement *= -1;
    
    }
 y += movement; 

    fill(10,2,0);
    circle(x, 200, 50);
    x++;
    if(x >= 800 || x<=0 ) {
        movement *= -1;
    
    }
 x += movement; 

    circle(a, 200, 50);
    a++;
    if(a >= 800 || a<=0 ) {
        movement *= -1;
    
    } 
 a += movement; 

    line(250, b, b, 270);
    b++;
    if(b >= 600 || b<=0 ) {
        movement *= -1;
    
    }
 b += movement; 

    point(250,y)

    y++;
    if(y >= 600 || y<=0 ) {
        movement *= -1;
    
    }
 y += movement; 

 textSize(size);
 size+= sizeDirection;
 count++;
 if(count > 5)
 {
    sizeDirection *=-1;
    count = 0;
 }
    text('Kaeli Moore', 10, 30);

}